import React from 'react';
import Home from './Home';


function App() {
  return (
    <main>
      <Home/>
    </main>
  );
}

export default App;
